# DMH 100 Feature Phone Simulator

A browser-based simulator of a classic 2G candybar feature phone (S30+-style interface). Plain HTML, CSS and JavaScript: no build step, no dependencies, no backend. Data (contacts, messages, call log, notes, photos, settings, high scores) is stored in `localStorage`.

> Unofficial fan project. "DMH" is a made-up name. Not affiliated with or endorsed by HMD Global, Nokia or Google. All calls, SMS and network behaviour are simulated.

## Run locally

Open `index.html` in a browser, or serve the folder:

```bash
python3 -m http.server 8000   # then visit http://localhost:8000
```

The camera needs `https://` or `localhost`.

## Features

Calls (dial, call log, fake incoming calls), contacts (up to 2,000, speed dial), SMS, Snake, calculator, alarm, calendar, stopwatch, timer, notes, FM radio, MP3 player, file manager and storage, flashlight, English Phone Talker, camera with compressed photos and gallery, a retro Internet browser, battery and charging simulation, startup/shutdown sounds.

## Controls

- Click the keys, or use the keyboard: arrows, `Enter` = OK, `Q` = left soft key, `Backspace` = right soft key / clear, `C` = call, `Esc` = end/back (hold = power), digits for the keypad.
- Text entry: multi-tap (press a key repeatedly to cycle its letters), hold a digit to type the number, `#` switches Abc/abc/123, `*` cycles symbols.
- Click the USB port to plug in the virtual charger.

## Notes

- The **Internet** app cannot load other sites inside the phone (sites block framing and browsers block cross-site requests). It simulates 2G loading and opens real search results and sites in a new tab.
- Browser autoplay rules mean sound starts after your first click or key press, so tap the screen or press the red key to power on.

## Push to GitHub and publish

```bash
cd dmh-100-simulator
git init
git add .
git commit -m "DMH 100 feature phone simulator"
git branch -M main
git remote add origin https://github.com/<your-username>/dmh-100-simulator.git
git push -u origin main
```

Then in the repository go to **Settings → Pages → Build and deployment → Source: GitHub Actions**. The included workflow deploys the site on every push to `main`.

Replace `<your name>` in `LICENSE` before publishing.
